# scatter plot of score vs popularity

import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

df=pd.read_csv(r"C:\Users\spriy\OneDrive\Desktop\Project Anime\animes2024.csv", encoding="latin1")

sns.set_style()
sns.lmplot(x='Score', y='Popularity', data=df)


plt.xlabel('Score')
plt.ylabel('Popularity')
plt.show()