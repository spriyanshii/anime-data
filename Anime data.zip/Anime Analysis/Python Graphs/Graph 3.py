#violin plot for score vs status

import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

df=pd.read_csv(r"C:\Users\spriy\OneDrive\Desktop\Project Anime\animes2024.csv", encoding="latin1")

sns.set_style()

color_palette = sns.color_palette("husl", n_colors=len(df['Type'].unique()))

sns.violinplot(x='Status', y='Score', data=df, hue='Type', legend=False, palette=color_palette)
plt.title('Distribution of Scores by Status')
plt.show()
