# pie chart for rate distribution

import pandas as pd
from matplotlib import pyplot as plt

df=pd.read_csv(r"C:\Users\spriy\OneDrive\Desktop\Project Anime\animes2024.csv", encoding="latin1")

rating_counts = df['Rating'].value_counts()

plt.figure(figsize=(8, 6))
plt.pie(rating_counts, labels=rating_counts.index, autopct='%1.1f%%', startangle=140)
plt.axis('equal')
plt.title('Rating Distribution of Anime')
plt.show()

