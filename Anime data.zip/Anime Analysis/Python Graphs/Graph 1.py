# graph of distribution of anime demographics

import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

df=pd.read_csv(r"C:\Users\spriy\OneDrive\Desktop\Project Anime\animes2024.csv", encoding="latin1")

plt.hist(df["Demographic"], histtype='bar', ec='black', color='violet')
plt.xlabel('Demographic')
plt.ylabel('Source')
plt.title('Anime Demographics')
plt.show()
